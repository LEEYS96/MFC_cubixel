#pragma once

class CStandardLibraryDlg : public CDialogEx
{
public:
	CStandardLibraryDlg(CWnd* pParent = NULL);	// standard constructor
	enum { IDD = IDD_STANDARDLIBRARY_DIALOG };

protected:
	HICON m_hIcon;

	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
};
